import { createStore } from "react-redux";

const initValue = {
  counter: 0,
  privacy: false
}
const counterReducer = (store = initValue, action) => {
  if (action.type == inc) {
    return { ...store, counter: store.counter + 1 }
  }
  else if (action.type == dec) {
    return { ...store, counter: store.counter - 1 }
  }
  else if (action.type == sub) {
    return { ...store, counter: store.counter - Number(action.payload.number) }
  }
  else if (action.type == add) {
    return { counter: store.counter + Number(action.payload.number) }
  }
  else if (action.type == privacy) {
    return { ...store, privacy: !store.privacy }
  }
  return store;
}
const store = createStore(counterReducer)

export default store;