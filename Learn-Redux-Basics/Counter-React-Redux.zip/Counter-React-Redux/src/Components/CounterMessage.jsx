import React from 'react'

export default function CounterMessage() {
  return (
    <div>
      <p className="lead mb-4">Counter message is private </p>
    </div>
  )
}
