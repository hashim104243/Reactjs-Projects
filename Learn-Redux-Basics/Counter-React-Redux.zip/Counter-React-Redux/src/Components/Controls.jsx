import React, { useRef } from 'react'
import { useDispatch } from 'react-redux'

export default function Controls() {
  const refInput = useRef();
  const dispatch = useDispatch();
  function handleIncreament() {
    dispatch({ type: "inc" })
  }
  function handleDec() {
    dispatch({ type: "dec" })
  }
  function AddValue() {
    dispatch({
      type: "add",
      payload: {
        number: refInput.current.value
      }
    })
  }
  function subtractValue() {
    dispatch({
      type: "sub",

      payload: {
        number: refInput.current.value
      }
    })
  }
  return (
    <div>
      <div className="d-grid gap-2 d-sm-flex justify-content-sm-center">
        <button onClick={handleIncreament} type="button" className="btn btn-primary">+1</button>

        <button onClick={handleDec} type="button" className="btn btn-success">-1</button>

      </div>

      <div className="d-grid gap-2 d-sm-flex justify-content-sm-center">
        <input ref={refInput} type="text" className="btn btn-primary" />
        <button onClick={AddValue} type="button" className="btn btn-primary">add</button>

        <button onClick={subtractValue} type="button" className="btn btn-success">subtract</button>
      </div>
    </div>
  )
}
